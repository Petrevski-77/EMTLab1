package mk.ukim.finki.wplab.Service;

import mk.ukim.finki.wplab.Model.Country;

import java.util.List;

public interface CountryService {
    List<Country> findAll();
}
