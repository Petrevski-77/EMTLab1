package mk.ukim.finki.wplab.Web.Controller;

import mk.ukim.finki.wplab.Model.Country;
import mk.ukim.finki.wplab.Service.CountryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/countries")
public class CountryRestController {
    private final CountryService countryService;

    public CountryRestController(CountryService countryService) {
        this.countryService = countryService;
    }
    @GetMapping
    ResponseEntity<List<Country>> findAll(){
        return ResponseEntity.ok(this.countryService.findAll());
    }
}
